##' Penalized empirical likelihood estimation for continuous-time models
##'
##' @description Maximum penalized empirical likelihood (EL) estimates are calculated by EM algorithms for continuous-time capture--recapture models, where individual covariates, time effect, and enduring behavioral responses to captures are consided.
##'
##' @usage
##' abun_ct(numCap = NULL, tau = NULL, t = NULL,
##'         t1 = NULL, x = NULL, model = "Mh",
##'         method = "EL", eps = 1E-5,
##'         maxN = NULL, Cp = 0, eps.newton = 1e-6)
##'
##' @param numCap A vector, whose elements represent the number of times that individuals are captured.
##' @param tau A number, which represents the time period of continuous-time capture--recapture experiments.
##' @param t A list, whose elements represent the time when individuals are captured.
##' @param t1 A vector, whose elements represent the time of an individuals being first captured. It needs to be assigned when the model \code{"Mhb"} is considered but the option \code{t} is unspecified.
##' @param x A matrix or data frame, where rows represent individuals captured and columns represent covariates. Note that the first element should not the constant one.
##' @param model A character of \code{"Mh"} (default), \code{"Mht"}, \code{"Mhb"}, or \code{"Mhtb"}, used to specify the capture intensity model.
##' @param method A character. \code{"EL"} (default) and \code{"PEL"} respectively represent the EL and penalized EL estimation methods.
##' @param eps A number, the tolerance of threshold, used to control the convergence of log-likelihood in EM algorithms. Default is \code{1e-05}.
##' @param maxN A number, the maximum value of \eqn{N} when searching for the estimate of the abundance parameter \eqn{N}. If \code{maxN = NULL} (default), it is automatically specified as \eqn{100*n}, where \eqn{n} is the number of individuals captured.
##' @param Cp A number, the penalty coefficient, which is used when the \code{method} is \code{"PEL"}. If \code{Cp = 0} (default), the EL method is implemented.
##' @param eps.newton A number, the tolerance of threshold for the Newton-Raphson algorithm when updating the regression coefficients under the models Mh and Mhb. Default is \code{1e-05}.
##'
##' @return A \code{abun_ct} object. For details, see \code{help(`abun_ct-class`)}.
##'
##' @details
##' The maximum EL estimator can be directly calculated by the function \code{abun_ct}.
##' The maximum penalized EL estimator can be obtained by setting the option \code{method} to \code{"PEL"}.
##' When the method is \code{"PEL"}, the default of \code{Cp} is
##' \eqn{{2 * n * (Nchao - n)^2}^{-1}}, where \eqn{Nchao = n + f1^2/(2*f2)} is the Chao (1987)'s lower bound.
##' Here, \eqn{f1} and \eqn{f2} are the number of individuals captured once and twice, respectively.
##'
##' When this function is called, the capture intensity model needs to be assigned.
##' There are four possible models: \code{"Mh"}, \code{"Mhb"}, \code{"Mht"}, and \code{"Mhtb"}.
##' Here, the subscripts \code{"h"}, \code{"t"}, and \code{"b"}
##' represent individual heterogeneity, time effect, and enduring behavioral response, respectively.
##'
##' \itemize{
##'
##'   \item When the model is \code{"Mh"}, three options need to be assigned:
##'   \code{numCap}, \code{tau}, and \code{x}.
##'
##'   \item When the model is \code{"Mhb"}, four options need to be assigned:
##'   \code{numCap}, \code{t1}, \code{tau}, and \code{x}.
##'
##'   \item When the model is \code{"Mht"} or \code{"Mhtb"}, three options need to be assigned:
##'   \code{t}, \code{tau}, and \code{x}.
##'
##' }
##'
##' The function \code{summary()} can be used to summarize the estimation results of \code{abun_ct()}.
##'
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' Liu, Y., Liu, Y., Li, P., and Qin, J. (2018).
##' Full likelihood inference for abundance from continuous time capture--recapture data.
##' \emph{Journal of the Royal Statistical Society: Series B (Statistical Methodology)}
##' \strong{80}, 995-1014.
##'
##' Liu, Y., Li, P., and Liu, Y. (2022).
##' Penalized empirical likelihood estimation and EM algorithms for closed-population capture--recapture models.
##'
##'
##' @examples
##' # Load the prinia data
##' data(prinia)
##'
##' # Fit model Mh to the prinia data
##' xcov <- as.matrix( cbind(prinia$x, prinia$x^2 ) )
##' prinia_el_h <- abun_ct( numCap = prinia$y, x = xcov, tau = 17, model = "Mh" )
##' summary(prinia_el_h)
##'
##'
##' @export
##'
abun_ct <- function(numCap = NULL, tau = NULL, t = NULL, t1 = NULL, x = NULL, model = "Mh", method = "EL", eps = 1E-5, maxN = NULL, Cp = 0, eps.newton = 1e-6){

  if (is.null(x)) stop("argument 'x' needs to be assigned")

  if ( ! (model %in% c("Mh", "Mht", "Mhb", "Mhtb")) )
    stop("argument 'model' needs to be assigned as 'Mh', 'Mht', 'Mhb', or 'Mhtb'")

  if ( is.null(tau) ) stop("argument 'tau' needs to be assigned")
  if ( is.null(numCap) & is.null(t) ) stop("argument 'numCap' or 't' needs to be assigned")

  if ( model == "Mh" ) {

    if ( !is.null(numCap) ) {
      rt <- abun_ct_h(numCap, tau, x, method, eps, maxN, Cp = Cp, eps.newton = eps.newton)
    } else {

      if ( !is.list(t) ) stop("argument 't' should be a list")
      numCap <- as.numeric( unlist( lapply(t, length) ) )
      rt <- abun_ct_h(numCap, tau, x, method, eps, maxN, Cp = Cp, eps.newton = eps.newton)
    }
  }

  if ( model == "Mhb" ) {

    if ( is.null(t) ) {

      if ( is.null(t1) ) stop("argument 't1' needs to be assigned")
      rt <- abun_ct_hb(numCap, t1, tau, x, method, eps, maxN, Cp = Cp, eps.newton = eps.newton)
    } else {

      if ( !is.list(t) ) stop("argument 't' should be a list")
      if (is.null(numCap)) numCap <- as.numeric( unlist( lapply(t, length) ) )
      t1 <- as.numeric( unlist( lapply(t, min) ) )
      rt <- abun_ct_hb(numCap, t1, tau, x, method, eps, maxN, Cp = Cp, eps.newton = eps.newton)
    }
  }

  if ( model == "Mht" ) {

    if ( !is.null(numCap) ) {
      rt <- abun_ct_ht ( numCap, x,  method, eps, maxN, Cp = Cp )
    } else {

      if ( !is.list(t) ) stop("argument 't' should be a list")
      numCap <- as.numeric( unlist( lapply(t, length) ) )
      rt <- abun_ct_ht ( numCap, x,  method, eps, maxN, Cp = Cp )
    }
  }

  if ( model == "Mhtb" ) {

    if ( is.null(t) ) stop("argument 't' needs to be assigned")
    rt <- abun_ct_htb(t, tau, x, method, eps, maxN, Cp = Cp)
  }

  rt
}


