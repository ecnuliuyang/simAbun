##' Bootstrap-based standard errors and confidence intervals for continuous-time models
##'
##' @description Function to calculate standard errors and confidence intervals based on a parametric bootstrap procedure for continuous-time capture--recapture models.
##'
##' @param object A \code{abun_ct} object
##' @param B A number, the number of bootstrap samples. Default is 200.
##' @param seed A number, the random seed. Default is 2021.
##' @return A list with four elements:
##'         \item{se_N}{the standard error of the abundance estimate.}
##'         \item{se_beta}{the standard errors of the regression coefficients' estimates.}
##'         \item{se_alpha}{the standard error of the probability of never being captured.}
##'         \item{quant_N}{the quantile estimates for the abundance estimates.}
##'
##' @importFrom stats quantile runif sd
##'
##' @export
##'
abun_ct_boot <- function (object, B = 200, seed = 2021) {

  # object = meth_el_hb
  rt <- list()
  x.true <- as.matrix( object@x )
  numCap.true <- object@numCap
  n.true <- nrow(x.true)
  N.true <- object@N

  set.seed(seed)
  N.b <- NULL
  beta.b <- NULL
  eta.b <- NULL
  alpha.b <- NULL

  ### generate bootstrap samples
  data.gen.ct <- function(){

    rt <- list()
    ind <- sample(1:N.true, N.true, replace = T)
    ind_cap <- ind[ind<n.true]
    rt$x <- as.matrix( x.true[ind_cap, ] )
    rt$numCap <- numCap.true[ind_cap]

    if ( object@model == "Mhb" )  rt$t1 <- object@t1[ind_cap]

    if ( object@model == "Mhtb" )
      rt$t <- lapply(object@t[ind_cap], function(x) x + runif(length(x),-1e-5, 1e-5) )

    return(rt)
  }

  b <- 1
  while (1) {

    if (b%%100 == 0) cat(b, "bootstrap replications are finished\n")
    dat.b <- data.gen.ct()
    x.b <- dat.b$x
    numCap.b <- dat.b$numCap

    if ( object@model == "Mhb" )  t1.b <- dat.b$t1
    if ( object@model == "Mhtb" )  t.b <- dat.b$t

    out.b <- switch ( object@model,
                      "Mh" = abun_ct_h(numCap.b, object@tau, x.b, object@method,
                                       object@eps, object@maxN, Cp = object@Cp, eps.newton = object@eps.newton ),
                      "Mhb" = abun_ct_hb(numCap.b, t1.b, object@tau, x.b, object@method,
                                         object@eps, object@maxN, Cp = object@Cp, eps.newton = object@eps.newton ),
                      "Mht" = abun_ct_ht(numCap.b, x.b, object@method,
                                         object@eps, object@maxN, Cp = object@Cp ),
                      "Mhtb" = abun_ct_htb(t.b, object@tau, x.b, object@method,
                                           object@eps, object@maxN, Cp = object@Cp ))
    N.b <- c(N.b, out.b@N)
    beta.b <- rbind(beta.b, out.b@beta)

    if ( object@model == "Mhb" | object@model == "Mhtb" ) {
      eta.b <- rbind(eta.b, out.b@eta)
    }
    alpha.b <- c(alpha.b, out.b@alpha)

    if (b == B) break()
    b <- b + 1
  }

  rt$se_N <- sd(N.b)
  rt$quant_N <- quantile(N.b, c(0.025, 0.05, 0.1, 0.9, 0.95, 0.975))
  rt$se_alpha <- sd(alpha.b)

  rt$se_beta <- apply(beta.b, 2, sd)
  name_x <- names(as.data.frame(object@x))
  names(rt$se_beta) <- switch(object@model,
                              "Mh"=c("Intercept", name_x),
                              "Mhb"=c("Intercept", name_x),
                              "Mht"=name_x,
                              "Mhtb"=name_x)

  if (object@model == "Mhb"|object@model == "Mhtb") {
    rt$se_eta <- sd(eta.b)
    names(rt$se_eta) <- "enduring behavior"
  }

  return(rt)

}

