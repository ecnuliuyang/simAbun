##' abun_ct class
##'
##' @description A S4 class is used to present the data and maximum penalized empirical likelihood (EL) estimates for continuous-time capture--recapture models.
##' @slot model A character of \code{"Mh"}, \code{"Mht"}, \code{"Mhb"}, or \code{"Mhtb"}, used to specify the continuous-time model.
##' @slot method A character. \code{"EL"} (default) and \code{"PEL"} respectively represent the EL and penalized EL estimation methods.
##' @slot N A number, the maximum PEL estimate of the population size.
##' @slot Nchao a number, the Chao (1987)'s lower bound.
##' @slot beta A vector, the maximum EL or penalized EL estimate of regression coefficients of covariates in capture intensity models.
##' @slot eta A number, the maximum EL or penalized EL estimate of the behavior effect in capture intensity models.
##' @slot alpha A number, the maximum EL or penalized EL estimate of the probability of never being captured.
##' @slot loglikelihood A number, the log EL or penalized log EL value.
##' @slot AIC A number, the Akaike Information Criterion value.
##' @slot prob A vector, the probability masses of individual covariates.
##' @slot hk A vector, the increments of the cumulative baseline intensity function.
##' @slot nit A number, the number of iterations for the EM algorithm.
##' @slot pars A matrix. Each row represents the iterative value of parameters.
##' @slot loglikelihoods A vector, the log-likelihood values in each iteration.
##' @slot numCap A vector, the number of times individuals were captured.
##' @slot tau A number, the time period of the CR experiment.
##' @slot t A list. Each element is a vector and represents the time when an individual was captured.
##' @slot t1 A vector, the time of an individuals being first captured.
##' @slot x A matrix, the individual covariates without the constant one.
##' @slot eps A number, the tolerance of threshold controling the convergence of log-likelihood in the EM algorithm.
##' @slot maxN A number, the maximum value for \eqn{N} when searching for the estimate of the population size \eqn{N}.
##' @slot Cp A number, the penalty coefficient when the penalized EL method is used.
##' @slot eps.newton A number, the tolerance of threshold for the Newton-Raphson algorithm when updating the regression coefficients under continuous time CR models Mh and Mhb.
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' @export
##'
setClass('abun_ct', slots =
           list( model = "character",
                 method = "character",
                 N = "numeric",
                 Nchao = "numeric",
                 beta = "numeric",
                 eta = "numeric",
                 alpha = "numeric",
                 loglikelihood = "numeric",
                 AIC =  "numeric",
                 prob = "numeric",
                 hk = "numeric",
                 nit = "numeric",
                 pars = "matrix",
                 loglikelihoods = "numeric",
                 numCap = "numeric",
                 tau = "numeric",
                 t = "list",
                 t1 = "numeric",
                 x = "matrix",
                 eps = "numeric",
                 maxN = "numeric",
                 Cp = "numeric",
                 eps.newton = "numeric" ) )




##' Function to show the the "abun_ct" object
##' @param object A \code{abun_ct} object.
setMethod("show", "abun_ct",

          function(object){

            cat(paste0("\nMaximum ", toupper(object@method)),
                "estimation for the continuous-time model", object@model, "\n\n")

            cat ("Maximum", object@method, "estimate of N:", round(object@N))
            cat ("\n")
            cat ("Maximum", object@method, "estimate of beta:", round(object@beta, 4L))
            if (object@model == "Mhb"|object@model == "Mhtb"){
              cat ("\n")
              cat ("Maximum", object@method, "estimate of eta:", round(object@eta, 4L))
            }
            # cat ("\n")
            # cat ("Maximum ", object@method, "estimate of alpha:", round(object@alpha, 4L))
            cat ("\n\n")
            cat ("Log-likelihood:", round(object@loglikelihood, 2L))
            cat ("\n")
            cat ("AIC:", round(object@AIC, 2L))

          })


##' abun_ct_summary
##'
##' @description A S4 class summarizes the maximum penalized empirical likelihood estimates for continuous-time capture--recapture models.
##' @slot coefficients A matrix, which summarizes the estimates of regression coefficients in capture intensity models.
##' @slot abundance A matrix, which summarizes the estimates of the population size.
##'
##' @export
##'
setClass( "abun_ct_summary", contains="abun_ct",
          slots = list( coefficients="matrix",
                        abundance = "matrix") )


##' Function to summarize the maximum penalized empirical likelihood estimates for continuous-time capture--recapture models
##' @param object A \code{abun_ct} object.
##' @importFrom methods new
##' @importFrom stats pnorm
##'
##' @export
##'
setMethod('summary', 'abun_ct',
          function(object) {

            rt <- new('abun_ct_summary',
                      model = object@model,
                      method = object@method,
                      N = object@N,
                      Nchao = object@Nchao,
                      beta = object@beta,
                      eta = object@eta,
                      alpha = object@alpha,
                      loglikelihood = object@loglikelihood,
                      AIC = object@AIC,
                      prob = object@prob,
                      hk =  object@hk,
                      nit = object@nit,
                      pars = object@pars,
                      loglikelihoods = object@loglikelihoods,
                      numCap = object@numCap,
                      tau =  object@tau,
                      t = object@t,
                      t1 =  object@t1,
                      x = object@x,
                      eps = object@eps,
                      maxN = object@maxN,
                      Cp = object@Cp,
                      eps.newton = object@eps.newton)

            # est_beta <- object@beta
            # se <- abun_ct_se(object)
            # se_beta <- se$se_beta
            # zval <- est_beta/abs(se_beta)
            # coefficients <- cbind(est_beta, se_beta,  zval, 2L * pnorm(abs(zval), lower.tail = FALSE))

            if (object@model == "Mhtb") {#stop("The asymptotic variance is not given under the model 'Mhtb'. The function 'abun_ct_boot' is recommended to calculate bootstrap-based variance estimates")
              est_coef <- c(object@beta, object@eta)
              out_se <- abun_ct_boot(object)
              se_coef <- c(out_se$se_beta, out_se$se_eta)
            }


            if (object@model == "Mh"|object@model == "Mht") {
              est_coef <- object@beta
              out_se <- abun_ct_se(object)
              se_coef <- out_se$se_beta
            }

            if(object@model == "Mhb") {
              est_coef <- c(object@beta, object@eta)
              out_se <- abun_ct_se(object)
              se_coef <- c(out_se$se_beta, out_se$se_eta)
            }

            zval <- est_coef/abs(se_coef)
            coefficients <- cbind(est_coef, se_coef,  zval, 2L * pnorm(abs(zval), lower.tail = FALSE))

            colnames(coefficients) <- c('Estimate', 'Std. Error', 'z value', 'Pr(>|z|)')

            name_x <- names(as.data.frame(rt@x))
            # paste0("beta(h)", 1L:ncol(rt@x))

            rownames(coefficients) <-
              switch ( rt@model,
                       "Mh" = c( "Intercept", name_x ),
                       "Mhb" = c( "Intercept", name_x, "enduring behavior" ),
                       "Mht" = name_x,
                       "Mhtb" = c(name_x, "enduring behavior" ) )

            rt@coefficients <- coefficients

            abundance <- matrix(c(round(object@N), round(out_se$se_N,2L)),1L)
            colnames(abundance) <- c("Estimate", "Std. Error" )
            rownames(abundance) <- '      '
            rt@abundance <- abundance
            return(rt)
          })


##' Function to show the "abun_ct_summary" object
##'
##' @param object A \code{abun_ct_summary} object.
##'
##' @importFrom stats printCoefmat
##'
setMethod('show', 'abun_ct_summary',
          function(object) {
            digits = max(3L, getOption("digits") - 3L)
            signif.stars = getOption("show.signif.stars")

            cat(paste0("\nMaximum ", toupper(object@method)),
                "estimates for continuous-time model",
                object@model, "\n")

            cat("Coefficients:\n")
            printCoefmat(object@coefficients, digits = digits, signif.stars = signif.stars, na.print = "NA")

            cat("\nAbundance:\n")
            print(object@abundance)

            cat ('\nLog-likelihood:', object@loglikelihood,
                 'with the AIC value being', round(object@AIC, 2L),
                 '\n\n')
            invisible(object)
          })
