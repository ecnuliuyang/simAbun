##' Penalized log EL for the continuous-time model Mhb
##'
##' @description Function to calculate the penalized empirical log-likelihood (log-EL) function for the continuous-time capture intensity model Mhb.
##'
##' @inheritParams abun_ct
##' @param N A number, the population size.
##' @param n A number, the sample size.
##' @param alpha A number, the probability of never being captured.
##' @param prob A vector, the probability masses of covariates.
##' @param x A matrix, where rows represent individuals captured and columns represent covariates.
##' @param beta A vector or matrix with a single column, the regression coefficients in the model \code{"Mhb"}.
##' @param eta A number, the behavior effect in the model \code{"Mhb"}.
##' @param Nchao A number, the Chao (1987)'s lower bound.
##'
##' @return A number, the penalized empirical log-likelihood.
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' @export
##'
loglikelihood_hb_ct <- function (N, n, alpha, prob, numCap, t1, x, beta, eta, tau, Cp, Nchao) {

  beta_x <- as.numeric( x%*%as.matrix(beta) )

  sum( log( N + 1 - c(1:n) ) ) - sum( log(1:n) ) +
    (N - n) * log( alpha + 1e-300 ) +
    sum( log( prob + 1e-300 ) ) +
    sum( numCap * beta_x + (numCap - 1) * eta -
           (tau * exp(eta) + t1*(1 - exp(eta)))*exp(beta_x) ) -
    Cp * (N - Nchao)^2 * (N > Nchao)
}


##' Maximum penalized EL estimates for the continuous-time model Mhb
##'
##' @description Function to calculate the maximum penalized empirical likelihood (EL) estimates for the continuous-time capture intensity model Mhb using the EM algorithm.
##'
##' @inheritParams abun_ct
##' @param N0 A number, at which the population size \eqn{N} is fixed when calculating the profile log-likelihood in the \code{\link{abun_ct_ci}} function. It is \code{NULL} when calculating the maximum penalized EL estimates.
##'
##' @return A \code{abun_ct} object.
##'
##' @importFrom methods new
##' @importFrom stats  coef glm optimize plogis
##'
##' @export
##'
abun_ct_hb <- function ( numCap, t1, tau, x, method = "EL",
                         eps = 1e-5, maxN = NULL, N0 = NULL, Cp = 0,
                         eps.newton = 1e-6 ) {

  ### initialization
  numCap <- as.numeric(numCap)
  n <- length(numCap)
  if( is.null(maxN) ) maxN <- 100*n

  ### Chao (1987)'s lower bound of N
  f1 <- sum(numCap == 1)
  f2 <- sum(numCap == 2)
  Nchao <- n + f1^2/(2*f2)
  Nchao <- min(Nchao, 1e20)
  if (method == "PEL" & Cp == 0)  Cp <- 2 * f2^2 / (n * f1^4)

  x_mat <- as.matrix( x )
  z_mat <- cbind( 1, x_mat )
  beta <- as.matrix( rep(0, ncol(z_mat)) )
  prob <- rep(1/n, n)
  phi <- as.numeric( exp( - tau*exp( z_mat%*%beta ) ) )
  alpha <- sum(phi * prob)
  eta <- log( sum(numCap - 1)/sum((tau-t1)*exp(z_mat%*%beta)) + 1e-300 )

  N <- ifelse ( is.null(N0), n/( 1 - alpha + 1e-300 ), N0 )

  pars<- c(N, beta, eta, alpha)
  likes <- loglikelihood_hb_ct(N, n, alpha, prob, numCap, t1, z_mat, beta, eta, tau, Cp, Nchao)


  ### iteration

  err <- 1; nit <- 0

  while (err > eps) {

    nit <- nit + 1

    ### update beta
    wi <- ( N - n ) * phi * prob/( alpha + 1e-300 )

    beta_newton_hb <- function (beta_in) {

      iter <- 0
      ### Newton - method
      while (1) {

        iter <- iter + 1

        delf <- function(beta) {
          e_phi <- sum(numCap-1)/sum((tau-t1)*exp(z_mat%*%beta))
          coef <- numCap - (tau*wi + tau*e_phi + (1-e_phi)*t1) * exp(z_mat%*%beta)
          as.numeric( t(z_mat) %*% coef )
        }

        del2f <- function(beta) {
          e_phi <- sum(numCap-1)/sum((tau-t1)*exp(z_mat%*%beta))
          coef1 <- (tau-t1)*exp(z_mat%*%beta)
          coef2 <- (tau*wi + (tau-t1)*e_phi + t1)*exp(z_mat%*%beta)
          as.matrix( t(z_mat)%*%coef1 ) %*% t(as.matrix(t(z_mat)%*%coef1))*e_phi /
            sum(coef1) - t(z_mat)%*%diag(as.numeric(coef2))%*%z_mat
        }

        coef_mat <- del2f(beta_in)
        coef_tri <- forwardsolve( t(chol(-coef_mat)), diag(1, nrow(coef_mat)))
        beta_in2 <- beta_in + t(coef_tri)%*%coef_tri%*%delf(beta_in)
        if(max(abs(beta_in2 - beta_in)) < eps.newton) break
        beta_in <- beta_in2
      }

      list( beta = beta_in2, iter = iter )
    }
    out_beta <- beta_newton_hb(beta)
    beta <- as.matrix( out_beta$beta )

    ell1 <- function (beta) {
      beta <- as.matrix(beta)
      eta <- log( sum(numCap - 1)/sum((tau-t1)*exp(z_mat%*%beta)) + 1e-300 )
      - sum(numCap*(z_mat%*%beta) + (numCap - 1)*eta -
              (tau*exp(eta) + t1*(1 - exp(eta)))*exp(z_mat%*%beta))
    }
    # out_beta <- nlminb(beta, ell1)
    # beta <- as.matrix(out_beta$par)
    phi <- as.numeric( exp( - tau*exp( z_mat%*%beta ) ) )
    eta <- log( sum(numCap - 1)/sum( (tau - t1)*
                                      exp(as.numeric(z_mat%*%beta)) ) + 1e-300)

    ### update prob & alpha
    prob <- (wi + 1) / N
    alpha <- sum( phi * prob )

    ### update N
    if ( is.null(N0) ){

      obj_N <- function (nt) {
        sum( log( nt + 1 - c(1:n) ) ) + (nt - n)*log(alpha + 1e-300) -
          Cp * (nt - Nchao)^2 * (nt > Nchao)
      }

      N <- optimize(obj_N, lower=n, upper=maxN, maximum=TRUE, tol = 0.01)$maximum
    }

    ### calculate the log-likelihood
    pars <- rbind(pars, c(N, beta, eta, alpha))
    likes <- c(likes, loglikelihood_hb_ct(N, n, alpha, prob, numCap, t1,
                                          z_mat, beta, eta, tau, Cp, Nchao))

    ### stopping criterion
    err <- abs( likes[nit+1] - likes[nit] )

  }

  AIC <- 2*( - likes[nit+1] + 3 + length(beta))

  rt <- new('abun_ct',
            model = "Mhb", method = method,
            N = N, Nchao = Nchao,
            beta = as.numeric(beta), eta = eta, alpha = alpha,
            loglikelihood = likes[nit+1], AIC = AIC,
            prob = prob, nit = nit, pars = pars, loglikelihoods = likes,
            numCap = numCap, t1 = t1, tau = tau, x = x_mat,
            eps = eps, maxN = maxN, Cp = Cp, eps.newton = eps.newton)
  return(rt)
}

