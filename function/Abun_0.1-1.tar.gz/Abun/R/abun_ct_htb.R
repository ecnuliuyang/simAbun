##' Penalized log EL for the continuous-time model Mhtb
##'
##' @description Function to calculate the penalized empirical log-likelihood (log EL) function for the continuous-time capture intensity model Mhtb.
##'
##' @inheritParams abun_ct
##'
##' @param N A number, the population size.
##' @param n A number, the sample size.
##' @param alpha A number, the probability of never being captured.
##' @param prob A vector, the probability masses of covariates.
##' @param x A matrix, where rows represent individuals captured and columns represent covariates.
##' @param beta A vector or matrix with a single column, the regression coefficients in the model \code{"Mhtb"}.
##' @param eta A number, the behavior effect in the model \code{"Mhtb"}.
##' @param hk A vector, the increments of the baseline cumulative intensity function.
##' @param Nchao A number, the Chao (1987)'s lower bound.
##'
##' @return A number, the penalized empirical log-likelihood.
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' @export
##'
loglikelihood_htb_ct <- function (N, n, alpha, prob, numCap, t, x, beta, eta, hk, Cp, Nchao) {

  t_sort <- sort(unlist(t))
  beta_x <- as.numeric( x%*%beta )

  sum( log( N + 1 - c(1:n) ) ) - sum( log(1:n) ) +
    (N - n) * log( alpha + 1e-300 ) +
    sum( log( prob + 1e-300 ) ) + sum( log( hk + 1e-300 ) ) +
    sum( numCap * beta_x + (numCap - 1) * eta -
           ( exp(eta) * sum(hk) + (1 - exp(eta))*
               unlist(lapply(t, function(x) sum(hk[t_sort<=min(x)])) )) *
           exp(beta_x) ) -
    Cp * (N - Nchao)^2 * (N > Nchao)
}


##' Maximum penalized EL estimates for the continuous-time model Mhtb
##'
##' @description Function to calculate the maximum penalized empirical likelihood (EL) estimates for the continuous-time capture intensity model Mhtb using the EM algorithm.
##'
##' @inheritParams abun_ct
##' @param N0 A number, at which the population size \eqn{N} is fixed when calculating the profile log-likelihood in the \code{\link{abun_ct_ci}} function. It is \code{NULL} when calculating the maximum penalized EL estimates.
##'
##' @return A \code{abun_ct} object.
##'
##' @importFrom methods new
##' @importFrom stats coef glm optimize plogis nlminb
##'
##' @export
##'
abun_ct_htb <- function ( t, tau, x, method = "EL",
                          eps = 1e-5, maxN = NULL, N0 = NULL, Cp = 0 ) {

  ### initialization
  numCap <- as.numeric( unlist( lapply(t, length) ) )
  n <- length(numCap)
  if ( is.null(maxN) ) maxN <- 100*n

  ### Chao (1987)'s lower bound of N
  f1 <- sum(numCap == 1)
  f2 <- sum(numCap == 2)
  Nchao <- n + f1^2/(2*f2)
  Nchao <- min(Nchao, 1e20)

  if (method == "PEL" & Cp == 0)  Cp <- 2 * f2^2 / (n * f1^4)

  t_sort <- sort(unlist(t))
  x_mat <- as.matrix( x )
  beta <- as.matrix( rep(0, ncol(x_mat)) )
  eta <- 0

  hk <- rep(1/length(t_sort),length(t_sort))
  phi <- as.numeric( exp( - sum(hk)*exp(x_mat%*%beta) ) )
  prob <- rep(1/n, n)
  alpha <- sum(phi * prob)

  N <- ifelse ( is.null(N0), n/( 1 - alpha + 1e-300 ), N0 )

  pars<- c(N, beta, eta, alpha)
  likes <- loglikelihood_htb_ct ( N, n, alpha, prob, numCap, t,
                                  x_mat, beta, eta, hk, Cp, Nchao )

  ### iteration

  err <- 1; nit <- 0

  while (err > eps) {
    nit <- nit + 1

    ### update beta
    wi <- ( N - n ) * phi * prob/( alpha + 1e-300 )

    beta_opt <- function (pars) {

      beta_in <- as.matrix(pars[1:(length(pars)-1)])
      eta_in <- pars[length(pars)]
      beta_x_in <- as.numeric(x_mat%*%beta_in)
      hk_in <- 1/( sum((exp(eta_in) + wi)*exp(beta_x_in)) +
                (1 - exp(eta_in)) * sapply(t_sort, function(t1)
                  sum((t1<= unlist(lapply(t, min)))*exp(beta_x_in))) )

      rt <- sum( numCap*beta_x_in + (numCap - 1)*eta_in ) +
        sum(log(hk_in+ 1e-300)) -
        sum(hk_in) * sum( (exp(eta_in) + wi)*exp(beta_x_in) ) -
        (1 - exp(eta_in))* sum(
          unlist(lapply(t, function(x) sum(hk_in*(t_sort<=min(x))) ))*
               exp(beta_x_in) )
      - rt
    }

    out_pars <- nlminb(c(beta, eta), beta_opt)$par
    beta <- as.matrix( out_pars[1:(length(out_pars)-1)] )
    eta <- out_pars[length(out_pars)]
    beta_x <- as.numeric( x_mat%*%beta )
    hk <- 1/( sum( (exp(eta) + wi)*exp(beta_x) ) +
                   (1 - exp(eta)) * sapply(t_sort, function(t1)
                     sum((t1<= unlist(lapply(t, min)))*exp(beta_x))) )
    phi <- exp( - sum(hk)*exp(beta_x) )


    ### update prob & alpha
    prob <- (wi + 1) / N
    alpha <- sum( phi * prob )

    ### update N
    if ( is.null(N0) ){

      obj_N <- function (nt) {
        sum( log( nt + 1 - c(1:n) ) ) + (nt - n)*log(alpha + 1e-300) -
          Cp * (nt - Nchao)^2 * (nt > Nchao)
      }

      N <- optimize(obj_N, lower=n, upper=maxN, maximum=TRUE, tol = 0.01)$maximum
    }

    ### calculate the log-likelihood
    pars <- rbind(pars, c(N, beta, eta, alpha))
    likes <- c(likes, loglikelihood_htb_ct( N, n, alpha, prob, numCap, t,
                                            x_mat, beta, eta, hk, Cp, Nchao) )

    ### stopping criteria
    err <- abs( likes[nit+1] - likes[nit] )

  }

  AIC <- 2*( - likes[nit+1] + 3 + length(beta))

  rt <- new('abun_ct',
            model = "Mhtb", method = method,
            N = N, Nchao = Nchao,
            beta = as.numeric(beta), eta = eta, alpha = alpha,
            hk = hk, loglikelihood = likes[nit+1], AIC = AIC,
            prob = prob, nit = nit, pars = pars, loglikelihoods = likes,
            numCap = numCap, t = t, tau = tau, x = x_mat,
            eps = eps, maxN = maxN, Cp = Cp)
  return(rt)
}

