##' Standard errors for the continuous-time models
##'
##' @description Function to calculate standard errors, based on the asymptotic normality, of the maximum penalized empirical likelihood estimates for the continuous-time capture--recapture models.
##'
##' @param object A \code{abun_ct} object.
##'
##' @return A list with three elements:
##' \itemize{
##'   \item se_N, the standard error for the population size.
##'   \item se_beta, the standard error for the regression coefficients in the capture intensity models.
##'   \item se_eta, the standard error for the behavioral effect under models \code{"Mhb"} and \code{"Mhtb"}.
##' }
##'
##'
##' @export
##'
abun_ct_se <- function (object) {

  switch( object@model,
          "Mh" = abun_ct_h_se(object),
          "Mht" = abun_ct_ht_se(object),
          "Mhb" = abun_ct_hb_se(object),
          "Mhtb" = "The asymptotic variance is not studied for the model 'Mhtb'. The function 'abun_ct_boot' is recommended to calculate bootstrap-based variance estimates.")

}


abun_ct_h_se <- function (object) {

  x_mat <- as.matrix( object@x )
  z_mat <- cbind(1, x_mat)
  tau <- object@tau
  numCap <- object@numCap
  n <- length(numCap)

  N <- object@N
  beta <- as.matrix(object@beta)
  beta_z <- as.numeric(z_mat%*%beta)
  phi <- exp(-tau*exp(beta_z))
  varphi <- sum( 1/(1-phi+1e-300)^2 )/N


  ### Vij's
  V22.coef <- ( (tau*exp(beta_z))^2*phi/(1-phi+1e-300) - tau*exp(beta_z) )/
    (1-phi+1e-300)
  V22 <- ( t(z_mat) %*% diag(V22.coef, n, n) %*% z_mat )/N
  V24 <- ( t(z_mat) %*% ( tau*exp(beta_z)*phi/(1-phi+1e-300)^2 ) )/N
  V22 <- as.matrix(V22)
  V24 <- as.matrix(V24)

  V22_chol <- forwardsolve( t(chol(- V22)), diag(1, nrow(V22)))
  se_beta_eta <- sqrt( diag( t(V22_chol)%*%V22_chol/N ) )
  V24_chol <- forwardsolve( t( chol( - V22) ), V24 )
  rt <- list( se_N = as.numeric( sqrt((varphi - 1 + t(V24_chol)%*%V24_chol)*N) ),
              se_beta = se_beta_eta )

  return(rt)

}


abun_ct_hb_se <- function (object) {

  x_mat <- as.matrix( object@x )
  z_mat <- cbind( 1, x_mat )

  t1 <- object@t1
  tau <- object@tau
  numCap <- object@numCap
  n <- length(numCap)
  N <- object@N
  eta <- object@eta
  beta <- as.matrix( object@beta )

  beta_z <- as.numeric(z_mat%*%beta)
  phi <- exp(-tau*exp(beta_z))
  varphi <- sum( 1/(1-phi+1e-300)^2 )/N


  ### Vij's
  V22.coef <- ( (tau*exp(beta_z)*phi)^2/(1-phi+1e-300) +
                  ( tau*exp(beta_z) )^2*phi - 1 - tau*exp(beta_z+eta) -
                  exp(eta - tau*exp(beta_z)) + exp(eta) +
                  exp(-tau*exp(beta_z)) )/(1-phi+1e-300)
  V22 <- ( t(z_mat) %*% diag(V22.coef, n, n) %*% z_mat )/N

  V23 <- - ( t(z_mat) %*% ( tau*exp(beta_z+eta)/(1-phi+1e-300) - exp(eta) ) )/N
  V24 <- ( t(z_mat) %*% ( tau*exp(beta_z)*phi/(1-phi+1e-300)^2 ) )/N
  V33 <- - sum( tau*exp(beta_z+eta)/(1-phi+1e-300) - exp(eta) )/N
  V22 <- as.matrix(V22)
  V23 <- as.matrix(V23)
  V24 <- as.matrix(V24)
  Vtheta <- rbind(cbind(V22, V23), cbind(t(V23), V33))
  Vtheta4 <- rbind(V24, 0)
  Vtheta_chol <- forwardsolve( t(chol(- Vtheta)), diag(1, nrow(Vtheta)))
  se_beta_eta <- sqrt( diag( t(Vtheta_chol)%*%Vtheta_chol/N ) )
  Vtheta4_chol <- forwardsolve( t( chol( - Vtheta) ), Vtheta4 )
  rt <- list( se_N = as.numeric( sqrt((varphi - 1 + t(Vtheta4_chol)%*%Vtheta4_chol)*N) ),
              se_beta = se_beta_eta[1:length(beta)],
              se_eta = se_beta_eta[length(se_beta_eta)])

  return(rt)

}


abun_ct_ht_se <- function (object) {

  x_mat <- as.matrix( object@x )
  numCap <- object@numCap
  n <- length(numCap)
  hk <- object@hk
  N <- object@N
  beta <- as.matrix(object@beta)
  beta_x <- as.numeric(x_mat%*%beta)

  phi0 <- sum(hk)
  pis <- 1 - exp( - phi0 * exp(beta_x) ) + 1e-20
  varphi <- sum( 1/pis^2 )/N


  ### Vij's
  V22.coef <- ( phi0 * exp( beta_x ) - (1 - pis) *
                  (phi0 * exp(beta_x))^2/pis )/ pis
  V22 <- ( t(x_mat) %*% diag(V22.coef, n, n) %*% x_mat )/N
  V23 <- ( t(x_mat) %*% (( exp(beta_x) - (1 - pis) *
                            phi0 * exp(2*beta_x)/pis )/pis) )/N
  V22 <- as.matrix(V22)
  V23 <- as.matrix(V23)
  V33 <- sum( (exp(beta_x)/(pis*phi0) - (1 - pis)/pis^2 * exp(2*beta_x))/pis )
  Vtheta <- rbind(cbind(V22, V23), cbind(t(V23), V33))

  V24 <- - phi0 *( t(x_mat) %*% ( (1 - pis) *
                                    exp(beta_x)/(pis^2) ) )/N
  V34 <- - sum( (1 - pis) * exp(beta_x)/(pis^2) )/N
  Vs2 <- as.matrix( rbind(V24, V34) )

  Vtheta_chol <- forwardsolve( t(chol(Vtheta)), diag(1, nrow(Vtheta)) )
  se_beta_eta <- sqrt( diag( t(Vtheta_chol)%*%Vtheta_chol/N ) )
  Vs_chol <- forwardsolve( t( chol(Vtheta) ), Vs2 )
  rt <- list( se_N = as.numeric( sqrt((varphi - 1 + t(Vs_chol)%*%Vs_chol)*N) ),
              se_beta = se_beta_eta[1:length(beta)] )

  return(rt)

}



