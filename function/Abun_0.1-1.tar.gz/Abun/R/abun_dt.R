##' Penalized empirical likelihood estimation for discrete-time models
##'
##' @description Maximum penalized empirical likelihood (EL) estimates are calculated by EM algorithms for discrete-time capture--recapture (CR) models, where individual covariates, time effect, enduring and ephemeral behavioral responses to captures are consided.
##'
##' @usage
##' abun_dt(histCap = NULL, numCap = NULL, K = NULL,
##'         t1 = NULL, x = NULL, model = "Mh",
##'         method = "EL", eps = 1E-5,
##'         maxN = NULL, Cp = 0)
##'
##' @param histCap A matrix or data frame, where rows represent individuals captured and columns represent capture occasions. The element is 1 if an individual is captured on certain capture occasion and 0 otherwise.
##' @param numCap A vector, whose elements represent the number of times that individuals are captured.
##' @param K A number, which represents the number of capture occasions.
##' @param t1 A vector, whose elements represent the time of an individuals being first captured. It needs to be assigned when the model \code{"Mhb"} is considered but the option \code{histCap} is \code{NULL}.
##' @param x A matrix or data frame, where rows represent individuals captured and columns represent covariates. Note that the first element should not the constant one.
##' @param model A character of \code{"Mh"} (default), \code{"Mht"}, \code{"Mhb"}, \code{"Mhtb"}, \code{"Mhc1"}, \code{"Mhtc1"}, \code{"Mhbc1"}, or \code{"Mhtbc1"}, used to specify the capture probability model.
##' @param method A character. \code{"EL"} (default) and \code{"PEL"} respectively represent the EL and penalized EL estimation methods.
##' @param eps A number, the tolerance of threshold, used to control the convergence of log-likelihood in EM algorithms. Default is \code{1e-05}.
##' @param maxN A number, the maximum value of \eqn{N} when searching for the estimate of the abundance parameter \eqn{N}. If \code{maxN = NULL} (default), it is automatically specified as \eqn{100*n}, where \eqn{n} is the number of individuals captured.
##' @param Cp A number, the penalty coefficient, which is used when the \code{method} is \code{"PEL"}. If \code{Cp = 0} (default), the EL method is implemented.
##'
##' @return A \code{abun_dt} object. For details, see \code{help(`abun_dt-class`)}.
##'
##' @details
##' The maximum EL estimator can be directly calculated by the function \code{abun_dt}.
##' The maximum penalized EL estimator can be obtained by setting the option \code{method} to \code{"PEL"}.
##' When the method is \code{"PEL"}, the default of \code{Cp} is
##' \eqn{{2 * n * (Nchao - n)^2}^{-1}}, where \eqn{Nchao = n + f1^2/(2*f2)} is the Chao (1987)'s lower bound.
##' Here, \eqn{f1} and \eqn{f2} are the number of individuals captured once and twice, respectively.
##'
##' When this function is called, the capture probability model needs to be assigned.
##' There are eight possible models: \code{"Mh"}, \code{"Mhb"}, \code{"Mht"}, \code{"Mhtb"},
##' \code{"Mhc1"}, \code{"Mhbc1"}, \code{"Mhtc1"}, and \code{"Mhtbc1"}.
##' Here the subscripts \code{"h"}, \code{"t"}, \code{"b"}, and \code{"c1"}
##' represents the individual heterogeneity, time effect, enduring behavioral response, and
##' ephemeral behavioral response, respectively.
##'
##' \itemize{
##'
##'   \item When the model is \code{"Mh"}, three options need to be assigned:
##'   \code{numCap}, \code{K}, and \code{x}.
##'
##'   \item When the model is \code{"Mhb"}, four options need to be assigned:
##'   \code{numCap}, \code{t1}, \code{K}, and \code{x}.
##'
##'   \item When other models are used, two options need to be assigned:
##'   \code{histCap} and \code{x}.
##'
##' }
##'
##' The function \code{summary()} can be used to summarize the estimation results of \code{abun_dt()}.
##'
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' Liu, Y., Li, P., and Qin, J. (2017).
##' Maximum empirical likelihood estimation for abundance in a closed population from capture--recapture data.
##' \emph{Biometrika} \strong{104}, 527-543.
##'
##' Liu, Y., Li, P., and Liu, Y. (2022).
##' Penalized empirical likelihood estimation and EM algorithms for closed-population capture--recapture models.
##'
##'
##' @examples
##' # Load the black bear data
##' data(blackbear)
##'
##' # Fit model Mhb to the black bear data
##' numCap <- apply(blackbear[,1:8], 1, sum)
##' t1 <- apply(blackbear[,1:8], 1, function(x) min(which(x == 1)))
##' x <- data.frame(sex = blackbear$sex)
##' bear_el_hb <- abun_dt(numCap = numCap, K = 8, t1 = t1,
##'                       x = x, model = "Mhb")
##' summary(bear_el_hb)
##'
##'
##' @export
##'
abun_dt <- function(histCap = NULL, numCap = NULL, K = NULL, t1 = NULL, x = NULL, model = "Mh", method = "EL", eps = 1E-5, maxN = NULL, Cp = 0){


  if ( ! (model %in% c("Mh", "Mht", "Mhb", "Mhtb", "Mhc1", "Mhtc1", "Mhbc1", "Mhtbc1")) )
    stop("argument 'model' needs to be assigned as 'Mh', 'Mht', 'Mhb', 'Mhtb', 'Mhc1', 'Mhtc1', 'Mhbc1', or 'Mhtbc1'")

  if ( is.null(histCap) & is.null(numCap) ) stop("argument 'histCap' or 'numCap' needs to be assigned")

  if ( is.null(histCap) ) {

    if ( (model!= "Mh") & (model!="Mhb") ) {
      stop("argument 'histCap' needs to be assigned when the model is not 'Mh' or 'Mhb'")
    } else {

      if ( is.null(K) ) stop("argument 'K' needs to be assigned")

      # Fit model Mh
      if ( model == "Mh" )  rt <- abun_dt_h(numCap, K, x, method, eps, maxN, Cp=Cp)

      # Fit model Mhb
      if ( model == "Mhb" ) {

        if ( is.null(t1) ) stop("argument 't1' needs to be assigned under the model Mhb")
        rt <- abun_dt_hb(numCap, K, t1, x, method, eps, maxN, Cp=Cp)
      }
    }

  } else {

    # Fit general models Mh, Mht, Mhb, Mhtb, Mhc1, Mhtc1, Mhbc1, and Mhtbc1
    rt <- abun_dt_htbc1(histCap, x, model, method, eps, maxN, Cp = Cp)
  }

  return(rt)
}


