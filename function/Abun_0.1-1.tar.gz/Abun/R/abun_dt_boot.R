##' Bootstrap-based standard errors and confidence intervals for discrete-time models
##'
##' @description Function to calculate standard errors and confidence intervals based on a bootstrap procedure for discrete-time capture--recapture models.
##'
##' @param object A \code{abun_dt} object.
##' @param B A number, the number of bootstrap samples. Default is 200.
##' @param seed A number, the random seed. Default is 2021.
##' @return A list with four elements:
##'         \item{se_N}{the standard error of the abundance estimate.}
##'         \item{se_beta}{the standard errors of the regression coefficients' estimates.}
##'         \item{se_alpha}{the standard error of the probability of never being captured.}
##'         \item{quant}{the quantiles of the sampling distribution of the abundance estimates.}
##'
##' @references
##'
##' Liu, Y., Li, P., and Qin, J. (2017).
##' Maximum empirical likelihood estimation for abundance in a closed population from capture--recapture data.
##' \emph{Biometrika} \strong{104}, 527-543.
##'
##'
##' @examples
##'
##' # Fit model Mhb to the black bear data
##' numCap <- apply(blackbear[,1:8], 1, sum)
##' t1 <- apply(blackbear[,1:8], 1, function(x) min(which(x == 1)))
##' bear_el_hb <- abun_dt(numCap = numCap, K = 8, t1 = t1,
##'                       x = blackbear$sex, model = "Mhb")
##'
##' # Calculate the Bootstrap-based standard errors and confidence intervals of the abundance parameter
##' bear_el_boot <- abun_dt_boot(bear_el_hb)
##' bear_el_boot$se_N
##' bear_el_boot$quant[c("2.5%", "97.5%")]
##'
##' @importFrom stats quantile rbinom sd
##'
##' @export
##'
abun_dt_boot <- function (object, B = 200, seed = 2021) {

  rt <- list()
  x.true <- as.matrix( object@x )
  prob.true <- object@prob
  n <- length(prob.true)
  K <- object@K
  N.true <- object@N
  beta.true <- object@beta

  set.seed(seed)
  N.b <- NULL
  beta.b <- NULL
  alpha.b <- NULL

  ### generate bootstrap samples
  data.gen.dt <- function(){

    ind <- sample(1:n, N.true, replace = T, prob = prob.true)
    x <- as.matrix( x.true[ind, ] )

    d_ext <- matrix( 0, N.true, K + 1 )

    for (i in 1:N.true) {

      for (k in 1:K) {

        zik <- zik_fun( x[i, ], K, k, (sum(d_ext[i, 1:k])>0) + 0, object@model )[,1]
        prob.cap <- plogis( sum(zik*beta.true) )
        d_ext[i,k+1] <- rbinom(1, 1, prob.cap)
      }
    }

    rt <- cbind(d_ext[,-1], x)[apply(d_ext, 1, sum)>0,]
    colnames(rt) <- c( paste0("d",rep(1:K)), paste0("x", 1:ncol(x)) )
    return(rt)
  }

  b <- 1
  while (1) {

    if (b%%100 == 0) cat(b, "bootstrap replications are finished\n")

    dat.b <- data.gen.dt()
    histCap.b <- dat.b[,1:K]
    x.b <- dat.b[,-(1:K)]

    numCap.b <- apply(histCap.b, 1, sum)
    t1.b <- apply(histCap.b, 1, function(x) min(which(x == 1)))

    out.b <- switch ( object@model,
                      "Mh" = abun_dt_h(numCap.b, K, x.b, object@method,
                                       object@eps, object@maxN, Cp = object@Cp ),
                      "Mhb" = abun_dt_hb(numCap.b, K, t1.b, x.b, object@method,
                                         object@eps, object@maxN, Cp = object@Cp ),
                      "Mht" = abun_dt_htbc1(histCap.b, x.b, object@model, object@method,
                                          object@eps, object@maxN, Cp = object@Cp ),
                      "Mhtb" = abun_dt_htbc1(histCap.b, x.b, object@model, object@method,
                                           object@eps, object@maxN, Cp = object@Cp ),
                      "Mhc1" = abun_dt_htbc1(histCap.b, x.b, object@model, object@method,
                                           object@eps, object@maxN, Cp = object@Cp ),
                      "Mhtc1" = abun_dt_htbc1(histCap.b, x.b, object@model, object@method,
                                            object@eps, object@maxN, Cp = object@Cp ),
                      "Mhbc1" = abun_dt_htbc1(histCap.b, x.b, object@model, object@method,
                                            object@eps, object@maxN, Cp = object@Cp ),
                      "Mhtbc1" = abun_dt_htbc1(histCap.b, x.b, object@model, object@method,
                                             object@eps, object@maxN, Cp = object@Cp ) )
    N.b <- c(N.b, out.b@N)
    beta.b <- rbind(beta.b, out.b@beta)
    alpha.b <- c(alpha.b, out.b@alpha)

    if (b == B) break()
    b <- b+1
  }

  rt$se_N <- sd(N.b)
  rt$quant <- quantile(N.b, c(0.025, 0.05, 0.1, 0.9, 0.95, 0.975))
  rt$se_alpha <- sd(alpha.b)

  rt$se_beta <- apply(beta.b, 2, sd)
  name_x <- names(as.data.frame(object@x))
  names(rt$se_beta) <- switch(object@model,
                              "Mh" = c( "Intercept", name_x ),
                              "Mhb" = c( "Intercept", name_x, "enduring behavior" ),
                              "Mht" = c( name_x, paste0("occasion ", 1L:rt@K) ),
                              "Mhtb" = c( name_x, paste0("occasion ", 1L:rt@K), "enduring behavior" ),
                              "Mhc1" = c( "Intercept", name_x, "ephemeral behavior" ),
                              "Mhtc1" = c( name_x, paste0("occasion ", 1L:rt@K), "ephemeral behavior" ),
                              "Mhbc1" = c( "Intercept", name_x, "beta(b)", "ephemeral behavior" ),
                              "Mhtbc1" = c( name_x, paste0("occasion ", 1L:rt@K), "enduring behavior", "ephemeral behavior" ) )
  return(rt)

}
