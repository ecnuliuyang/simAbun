##' Penalized EL ratio confidence interval for discrete-time models
##'
##' @description Penalized empirical likelihood (EL) ratio confidence interval of the abundance parameter \eqn{N} is calculated for discrete-time capture--recapture models.
##'
##' @param object A \code{abun_dt} object.
##' @param level A number, the nominal level. Default is 0.95.
##' @param UB A number, the upper bound when searching for the upper limit of \eqn{N}. Default is \eqn{1e+09}.
##'
##' @return A vector, the penalized EL ratio confidence interval of \eqn{N}.
##'
##'
##' @references
##'
##' Liu, Y., Li, P., and Qin, J. (2017).
##' Maximum empirical likelihood estimation for abundance in a closed population from capture--recapture data.
##' \emph{Biometrika} \strong{104}, 527-543.
##'
##' @examples
##'
##' # Fit model Mhb to the black bear data
##' numCap <- apply(blackbear[,1:8], 1, sum)
##' t1 <- apply(blackbear[,1:8], 1, function(x) min(which(x == 1)))
##' x <- data.frame(sex = blackbear$sex)
##' bear_el_hb <- abun_dt(numCap = numCap, K = 8, t1 = t1,
##'                       x = x, model = "Mhb")
##'
##' # Calculate the EL ratio confidence interval of the abundance parameter
##' abun_dt_ci(bear_el_hb)
##'
##' @importFrom stats qnorm qchisq uniroot
##'
##' @export
##'
abun_dt_ci <- function ( object, level = 0.95, UB = 1e9 ) {

  ###  maximum penalized empirical log-likelihood
  like_full <- object@loglikelihood
  n <- length(object@numCap)

  rn <- function (N0) {

    like_null <- switch (object@model,
                         "Mh" = abun_dt_h(object@numCap, object@K, object@x, object@method,
                                          object@eps, object@maxN, N0, object@Cp ),
                         "Mhb" = abun_dt_hb(object@numCap, object@K, object@t1, object@x, object@method,
                                            object@eps, object@maxN, N0, object@Cp ),
                         "Mht" = abun_dt_htbc1(object@histCap, object@x, object@model, object@method,
                                               object@eps, object@maxN, N0, object@Cp ),
                         "Mhtb" = abun_dt_htbc1(object@histCap, object@x, object@model, object@method,
                                                object@eps, object@maxN, N0, object@Cp ),
                         "Mhc1" = abun_dt_htbc1(object@histCap, object@x, object@model, object@method,
                                                object@eps, object@maxN, N0, object@Cp ),
                         "Mhtc1" = abun_dt_htbc1(object@histCap, object@x, object@model, object@method,
                                                 object@eps, object@maxN, N0, object@Cp ),
                         "Mhbc1" = abun_dt_htbc1(object@histCap, object@x, object@model, object@method,
                                                 object@eps, object@maxN, N0, object@Cp ),
                         "Mhtbc1" = abun_dt_htbc1(object@histCap, object@x, object@model, object@method,
                                                  object@eps, object@maxN, N0, object@Cp ))

    2 * ( like_full - like_null@loglikelihood ) - qchisq(level, 1)

  }

  hatN <- object@N
  ntemp <- c(hatN, 10 * hatN)
  nit <- 2
  ind <- rn(ntemp[nit]) <= 0
  while ( ind ) {

    ntemp <- c(ntemp, ntemp[nit]*10)
    nit <- nit+1
    ind <- rn(ntemp[nit]) <= 0

    if (ntemp[nit] >= UB) {
      ci_upper = UB
      break
    }

  }

  if (!ind & ntemp[nit] < UB)  ci_upper <- uniroot( rn, c(ntemp[nit-1], ntemp[nit]), tol=0.01 )$root


  if ( rn(n) <= 0 ) {
    ci_lower <- n
  } else {
    ci_lower <- uniroot( rn, c(n, hatN), tol=0.01 )$root
  }

  return( c(ci_lower, ci_upper) )

}



