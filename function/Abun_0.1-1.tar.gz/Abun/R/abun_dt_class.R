##' abun_dt class
##'
##' @description A S4 class is used to present the data and maximum penalized empirical likelihood (EL) estimates for discrete-time capture--recapture models.
##' @slot model A character of \code{"Mh"}, \code{"Mht"}, \code{"Mhb"}, \code{"Mhtb"}, \code{"Mhc1"}, \code{"Mhtc1"}, \code{"Mhbc1"} or \code{"Mhtbc1"}, used to specify the capture probability model.
##' @slot method A character. \code{"EL"} and \code{"PEL"} stand for the EL and penalized EL estimation methods, respectively.
##' @slot N A number, the maximum EL or PEL estimate of the population size.
##' @slot Nchao A number, the Chao (1987)'s lower bound.
##' @slot beta A vector, the maximum EL or penalized EL estimates of regression coefficients in capture probability models.
##' @slot alpha A number, the maximum EL or penalized EL estimate of the probability of never being captured.
##' @slot loglikelihood A number, the log EL or penalized log EL value.
##' @slot AIC A number, the Akaike Information Criterion value.
##' @slot prob A vector, the probability masses of individual covariates.
##' @slot nit A number, the number of iterations of EM algorithms.
##' @slot pars A matrix. Row represent the iterative values of parameters.
##' @slot loglikelihoods A vector, the log-likelihood values in iteration.
##' @slot histCap A matrix or data frame, where rows represent individuals captured and columns represent capture occasions. The element is 1 if an individual is captured on certain capture occasion and 0 otherwise.
##' @slot numCap A vector, whose elements represent the number of times that individuals are captured.
##' @slot K A number, the number of capture occasions.
##' @slot t1 A vector, whose elements represent the time of an individuals being first captured.
##' @slot x A matrix, the individual covariates without the constant one.
##' @slot eps A number, the tolerance of threshold controling the convergence of log-likelihood in EM algorithms.
##' @slot maxN A number, the maximum value for \eqn{N} when searching for the estimate of the population size \eqn{N}.
##' @slot Cp A number, the penalty coefficient when the penalized EL method is used.
##'
##' @export
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
setClass( 'abun_dt', slots =
            list( model = "character",
                  method = "character",
                  N = "numeric",
                  Nchao = "numeric",
                  beta = "numeric",
                  alpha = "numeric",
                  loglikelihood = "numeric",
                  AIC =  "numeric",
                  prob = "numeric",
                  nit = "numeric",
                  pars = "matrix",
                  loglikelihoods = "numeric",
                  histCap = "matrix",
                  numCap = "numeric",
                  K = "numeric",
                  t1 = "numeric",
                  x = "matrix",
                  eps = "numeric",
                  maxN = "numeric",
                  Cp = "numeric" ) )


##' Function to show the \code{abun_dt} object
##'
##' @param object \code{abun_dt} object
setMethod("show", "abun_dt",

          function(object){

            coefficients <- round(object@beta, 4L)
            # names(coefficients) <-
            #   switch ( object@model,
            #            "Mh" = c( "Intercept", paste0("beta(h)", 1L:ncol(object@x)) ),
            #            "Mhb" = c( "Intercept", paste0("beta(h)", 1L:ncol(object@x)), "beta(b)" ),
            #            "Mht" = c( paste0("beta(h)", 1L:ncol(object@x)), paste0("beta(t)", 1L:object@K) ),
            #            "Mhtb" = c( paste0("beta(h)", 1L:ncol(object@x)), paste0("beta(t)", 1L:object@K), "beta(b)" ),
            #            "Mhc1" = c( "Intercept", paste0("beta(h)", 1L:ncol(object@x)), "beta(c1)" ),
            #            "Mhtc1" = c( paste0("beta(h)", 1L:ncol(object@x)), paste0("beta(t)", 1L:object@K), "beta(c1)" ),
            #            "Mhbc1" = c( "Intercept", paste0("beta(h)", 1L:ncol(object@x)), "beta(b)", "beta(c1)" ),
            #            "Mhtbc1" = c( paste0("beta(h)", 1L:ncol(object@x)), paste0("beta(t)", 1L:object@K), "beta(b)", "beta(c1)" ) )

            cat(paste0("\nMaximum ", toupper(object@method)),
                "estimation for the discrete-time model", object@model, "\n\n")

            cat ("Maximum", object@method, "estimate of N:", round(object@N))
            cat ("\n")
            cat ("Maximum", object@method, "estimate of beta:", coefficients)
            # cat ("\n")
            # cat ("Maximum", object@method, "estimate of alpha:", round(object@alpha, 4L))
            cat ("\n\n")
            cat ("Log-likelihood:", round(object@loglikelihood, 2L))
            cat ("\n")
            cat ("AIC:", round(object@AIC, 2L))

          })


##' abun_dt_summary class
##'
##' @description A S4 class summarizes the maximum (penalized) empirical likelihood estimates for discrete-time capture--recapture models.
##' @slot coefficients A matrix, which summarizes the estimates of regression coefficients in capture probability models.
##' @slot abundance A matrix, which summarizes the estimates of the population size.
##'
##' @export
##'
setClass( "abun_dt_summary", contains = "abun_dt",
          slots = list( coefficients = "matrix",
                        abundance = "matrix" ) )


##' Function to summarize the maximum (penalized) empirical likelihood estimates for discrete-time capture--recapture models
##'
##' @param object a \code{abun_dt} object
##'
##' @importFrom methods new
##' @importFrom stats pnorm
##'
##' @export
##'
setMethod('summary', 'abun_dt',
          function(object) {
            rt <- new('abun_dt_summary',
                      model = object@model,
                      method = object@method,
                      N = object@N,
                      Nchao = object@Nchao,
                      beta = object@beta,
                      alpha = object@alpha,
                      loglikelihood = object@loglikelihood,
                      AIC = object@AIC,
                      prob = object@prob,
                      nit = object@nit,
                      pars = object@pars,
                      loglikelihoods = object@loglikelihoods,
                      histCap = object@histCap,
                      numCap = object@numCap,
                      K = object@K,
                      t1 = object@t1,
                      x = object@x,
                      eps = object@eps,
                      maxN = object@maxN,
                      Cp = object@Cp)

            est_beta <- object@beta
            se <- abun_dt_se(object)
            se_beta <- se$se_beta
            zval <- est_beta/abs(se_beta)
            coefficients <- cbind(est_beta, se_beta,  zval, 2L * pnorm(abs(zval), lower.tail = FALSE))
            colnames(coefficients) <- c('Estimate', 'Std. Error', 'z value', 'Pr(>|z|)')

            name_x <- names(as.data.frame(rt@x))
            rownames(coefficients) <-
              switch ( rt@model,
                       "Mh" = c( "Intercept", name_x ),
                       "Mhb" = c( "Intercept", name_x, "enduring behavior" ),
                       "Mht" = c( name_x, paste0("occasion ", 1L:rt@K) ),
                       "Mhtb" = c( name_x, paste0("occasion ", 1L:rt@K), "enduring behavior" ),
                       "Mhc1" = c( "Intercept", name_x, "ephemeral behavior" ),
                       "Mhtc1" = c( name_x, paste0("occasion ", 1L:rt@K), "ephemeral behavior" ),
                       "Mhbc1" = c( "Intercept", name_x, "beta(b)", "ephemeral behavior" ),
                       "Mhtbc1" = c( name_x, paste0("occasion ", 1L:rt@K), "enduring behavior", "ephemeral behavior" ) )

            rt@coefficients <- coefficients

            abundance <- matrix(c(round(object@N), round(se$se_N,2L)), 1L)
            colnames(abundance) <- c("Estimate", "Std. Error" )
            rownames(abundance) <- '      '
            rt@abundance <- abundance
            return(rt)
          })


##' Function to show the \code{abun_dt_summary} object
##'
##' @param object \code{abun_dt_summary} object
##' @importFrom stats printCoefmat
##'
setMethod('show', 'abun_dt_summary',
          function(object) {
            digits = max(3L, getOption("digits") - 3L)
            signif.stars = getOption("show.signif.stars")

            cat(paste0("\nMaximum ", toupper(object@method)),
                "estimates for the discrete-time model",
                object@model, "\n")

            cat("Coefficients:\n")
            printCoefmat(object@coefficients, digits = digits, signif.stars = signif.stars, na.print = "NA")

            cat("\nAbundance:\n")
            print(object@abundance)

            cat ('\nLog-likelihood:', object@loglikelihood,
                 'with the AIC value being', round(object@AIC, 2L),
                 '\n\n')
            invisible(object)
          })
