##' Penalized log EL for the discrete-time model Mh
##'
##' @description Function to calculate the penalized empirical log-likelihood (log EL) function for the discrete-time capture probability model Mh.
##'
##' @inheritParams abun_dt
##' @param N A number, the population size.
##' @param n A number, the sample size.
##' @param alpha A number, the probability of never being captured.
##' @param prob A vector, the probability masses of covariates.
##' @param z_mat A matrix, where rows represent individuals captured and columns represent covariates.
##' @param beta A vector or matrix with a single column, the regression coefficients in the model \code{"Mh"}.
##' @param Nchao A number, the Chao (1987)'s lower bound.
##'
##' @return A number, the penalized empirical log-likelihood.
##'
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' @importFrom stats plogis
##'
##' @export
##'
loglikelihood_h <- function (N, n, alpha, prob, numCap, z_mat, beta, K, Cp, Nchao ) {

  g <- plogis( as.numeric(z_mat%*%as.matrix(beta)) )

  sum( log( N + 1 - c(1:n) ) ) - sum( log(1:n) ) + (N - n) * log( alpha + 1e-300 ) +
    sum( numCap * log(g + 1e-300) + (K - numCap) * log(1 - g + 1e-300) ) +
    sum( log( prob + 1e-300 ) ) -
    Cp * (N - Nchao)^2 * (N > Nchao)
}


##' Maximum penalized EL estimates for the discrete-time model Mh
##'
##' @description Function to calculate the maximum penalized empirical likelihood (EL) estimates for the discrete time capture probability model Mh using the EM algorithm.
##'
##' @inheritParams abun_dt
##' @param N0 A number, at which the population size \eqn{N} is fixed when calculating the profile log-likelihood in the \code{\link{abun_dt_ci}} function. It is \code{NULL} when calculating the maximum penalized EL estimates.
##'
##'
##' @return A \code{abun_dt} object.
##'
##' @importFrom methods new
##' @importFrom stats coef glm optimize plogis
##'
##' @export
##'
abun_dt_h <- function ( numCap, K, x, method = "EL",
                          eps = 1e-5, maxN = NULL, N0 = NULL, Cp = 0 ) {

  ### initialization
  numCap <- as.numeric(numCap)
  n <- length(numCap)
  if( is.null(maxN) ) maxN <- 100*n


  ### Chao (1987)'s lower bound of N
  f1 <- sum(numCap == 1)
  f2 <- sum(numCap == 2)
  Nchao <- n + f1^2/(2*f2)
  Nchao <- min(Nchao, 1e20)

  if ( method == "PEL" & Cp == 0 )  Cp <- 2 * f2^2 / (n * f1^4)

  x_mat <- as.matrix( x )
  z_mat <- cbind(1, x_mat)
  nx <- rbind(z_mat, z_mat)
  ny <- c(numCap, rep(0,n))
  nk <- rep(K, 2*n)

  beta <- as.matrix( rep(0, ncol(z_mat)) )
  prob <- rep(1/n, n)
  g <- plogis( as.numeric(z_mat%*%beta) )
  phi <- (1 - g)^K
  alpha <- sum(phi * prob)

  N <- ifelse ( is.null(N0), n/( 1 - alpha + 1e-300 ), N0 )

  pars<- c(N, beta, alpha)
  likes <- loglikelihood_h(N, n, alpha, prob, numCap, z_mat, beta, K, Cp, Nchao)


  ### iteration

  err <- 1; nit <- 0

  while (err > eps) {

    nit <- nit + 1

    ### update beta
    wi <- ( N - n ) * phi * prob/( alpha + 1e-300 )
    nwi <- c(rep(1,n), wi)
    out <- glm(cbind(ny, nk-ny) ~ nx - 1, family="binomial", weights=nwi)
    beta <- as.matrix( coef(out) )

    g <- plogis( as.numeric(z_mat%*%beta) )
    phi <- (1 - g)^K

    ### update prob & alpha
    prob <- (wi + 1) / N
    alpha <- sum( phi * prob )


    ### update N
    if ( is.null(N0) ){

      obj_N <- function (nt) {
        sum( log( nt + 1 - c(1:n) ) ) + (nt - n)*log(alpha + 1e-300) -
          Cp * (nt - Nchao)^2 * (nt > Nchao)
      }

      N <- optimize(obj_N, lower=n, upper=maxN, maximum=TRUE, tol = 0.001)$maximum
    }


    ### calculate the log-likelihood
    pars <- rbind(pars, c(N, beta, alpha))
    likes <- c(likes, loglikelihood_h(N, n, alpha, prob, numCap, z_mat, beta, K, Cp, Nchao))


    ### stopping criterion
    err <- abs( likes[nit+1] - likes[nit] )

  }

  AIC <- 2*( - likes[nit+1] + 2 + length(beta))

  rt <- new('abun_dt',
            model = "Mh", method = method,
            N = N, Nchao = Nchao,
            beta = as.numeric(beta), alpha = alpha,
            loglikelihood = likes[nit+1], AIC = AIC,
            prob = prob, nit = nit, pars = pars, loglikelihoods = likes,
            numCap = numCap, K = K, x = x_mat,
            eps = eps, maxN = maxN, Cp = Cp)
  return(rt)
}


