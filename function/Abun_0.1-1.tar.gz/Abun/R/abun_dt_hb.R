##' Penalized log EL for the discrete-time model Mhb
##'
##' @description Function to calculate the penalized empirical log-likelihood (log EL) function for the discrete-time capture probability model Mhb
##'
##' @inheritParams abun_dt
##' @param N A number, the population size.
##' @param n A number, the sample size.
##' @param alpha A number, the probability of never being captured.
##' @param prob A vector, the probability masses of covariates.
##' @param z_mat A matrix, the covariates without the behavioral term.
##' @param beta A vector or matrix with a single column, the regression coefficients in the model \code{"Mhb"}.
##' @param Nchao A number, the Chao (1987)'s lower bound.
##'
##' @return A number, the penalized empirical log-likelihood.
##'
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' @importFrom stats plogis
##'
##' @export
##'
loglikelihood_hb <- function (N, n, alpha, prob, numCap, K, t1, z_mat, beta, Cp, Nchao ) {

  beta <- as.numeric(beta)
  out <- 0
  for (i in 1:n) {
    out <- out + (t1[i] - 1)*log( 1 - plogis( sum(c(z_mat[i,],0)*beta) )) +
      log( plogis(sum(c(z_mat[i,],0)*beta)) ) +
      (numCap[i] - 1) * log( plogis(sum(c(z_mat[i,],1)*beta)) ) +
      (K - t1[i] - numCap[i] + 1) * log(1 - plogis(sum(c(z_mat[i,],1)*beta)))
  }

  sum( log( N + 1 - c(1:n) ) ) - sum(log(1:n)) +
    (N - n) * log( alpha + 1e-300 ) + out +
    sum( log( prob + 1e-300 ) ) -
    Cp * (N - Nchao)^2 * (N > Nchao)
}


##' Maximum penalized EL estimates for the discrete-time model Mhb
##'
##' @description  Function to calculate the maximum penalized empirical likelihood (EL) estimates for the discrete-time capture probability model Mhb using the EM algorithm.
##'
##' @inheritParams abun_dt
##' @param N0 A number, at which the population size \eqn{N} is fixed when calculating the profile log-likelihood in the \code{\link{abun_dt_ci}} function. It is \code{NULL} when calculating the maximum penalized EL estimates.
##'
##' @return A \code{abun_dt} object
##'
##' @importFrom methods new
##' @importFrom stats coef glm optimize plogis
##'
##' @export
##'
abun_dt_hb <- function ( numCap, K, t1, x, method = "EL",
                         eps = 1e-5, maxN = NULL, N0 = NULL, Cp = 0 ) {

  ### initialization
  numCap <- as.numeric(numCap)
  n <- length(numCap)
  if( is.null(maxN) ) maxN <- 100*n

  ### Chao (1987)'s lower bound of N
  f1 <- sum(numCap == 1)
  f2 <- sum(numCap == 2)
  Nchao <- n + f1^2/(2*f2)
  Nchao <- min(Nchao, 1e20)

  if (method == "PEL" & Cp == 0)  Cp <- 2 * f2^2 / (n * f1^4)

  x_mat <- as.matrix( x )
  z_mat <- cbind(1, x_mat)
  bt_dim <- ncol(z_mat) + 1

  nx <- NULL
  ny <- NULL

  for (i in 1:n) {

    ny <- c(ny, 0, 1)
    nx <- rbind(nx, c(z_mat[i,], 0), c(z_mat[i,], 0) )

    if (numCap[i]>1) {
      ny <- c(ny, 1)
      nx <- rbind(nx, c(z_mat[i,], 1) )
    }

    if (K - t1[i] - numCap[i] + 1 > 0) {
      ny <- c(ny, 0)
      nx <- rbind(nx, c(z_mat[i,], 1))
    }
  }

  beta <- as.matrix( rep(0, bt_dim) )
  prob <- rep(1/n, n)
  phi <- as.numeric((1 - plogis(cbind(z_mat,0)%*%beta))^K)
  alpha <- sum(phi * prob)

  N <- ifelse ( is.null(N0), n/( 1 - alpha + 1e-300 ), N0 )

  pars<- c(N, beta, alpha)
  likes <- loglikelihood_hb( N, n, alpha, prob, numCap, K, t1, z_mat, beta, Cp, Nchao )


  ### iteration

  err <- 1; nit <- 0

  while (err > eps) {

    nit <- nit + 1

    ### update beta
    wi <- ( N - n ) * phi * prob/( alpha + 1e-300 )

    nwi <- NULL
    for(i in 1:n) {

      nwi <- c( nwi, K*wi[i] + t1[i] - 1, 1 )
      if (numCap[i]>1)  nwi <- c(nwi, numCap[i] -1)
      if (K - t1[i] - numCap[i]+1>0)  nwi <- c(nwi, (K - t1[i] - numCap[i]+1) )
    }

    out <- glm(ny ~ nx - 1, family="binomial", weights=nwi)
    beta <- as.matrix( coef(out) )
    phi <- as.numeric( (1 - plogis(cbind(z_mat,0)%*%beta))^K)

    ### update prob & alpha
    prob <- (wi + 1) / N
    alpha <- sum( phi * prob )

    ### update N
    if ( is.null(N0) ){

      obj_N <- function (nt) {
        sum( log( nt + 1 - c(1:n) ) ) + (nt - n)*log(alpha + 1e-300) -
          Cp * (nt - Nchao)^2 * (nt > Nchao)
      }

      N <- optimize(obj_N, lower=n, upper=maxN, maximum=TRUE, tol = 0.001)$maximum
    }

    ### calculate the log-likelihood
    pars <- rbind(pars, c(N, beta, alpha))
    likes <- c(likes, loglikelihood_hb(N, n, alpha, prob, numCap, K, t1, z_mat, beta, Cp, Nchao) )

    ### stopping criterion
    err <- abs( likes[nit+1] - likes[nit] )

  }

  AIC <- 2*( - likes[nit+1] + 2 + length(beta))

  rt <- new('abun_dt',
            model = "Mhb", method = method,
            N = N, Nchao = Nchao,
            beta = as.numeric(beta), alpha = alpha,
            loglikelihood = likes[nit+1], AIC = AIC,
            prob = prob, nit = nit, pars = pars, loglikelihoods = likes,
            numCap = numCap, K = K, t1 = t1, x = x_mat,
            eps = eps, maxN = maxN, Cp = Cp)
  return(rt)
}


