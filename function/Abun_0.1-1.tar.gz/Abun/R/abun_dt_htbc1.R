##' \eqn{z_{ik}} and \eqn{z_{ik0}} for the discrete-time models "Mh", "Mht", "Mhb", "Mhtb", "Mhc1", and "Mhtc1"
##'
##' @description Function to calculate \eqn{z_{ik}} and \eqn{z_{ik0}} used in the function \code{\link{abun_dt_htbc1}}.
##'
##' @param x A vector, the individual covariates without the constant one.
##' @param K A number, the number of capture occasions.
##' @param k A number, the current capture occasion.
##' @param histCap_individual A vector with elements being 0 or 1. If the \code{model} is \code{"Mhb"} or \code{"Mhtb"}, 1 means that individual was captured up to occasion \eqn{k} and 0 otherwise. If the \code{model} is \code{"Mhc1"} or \code{"Mhtc1"}, 1 means that individual was captured on occasion \eqn{k-1} and 0 otherwise.
##' @param model A character, used to specify the model \code{"Mh"}, \code{"Mht"}, \code{"Mhb"}, \code{"Mhtb"}, \code{"Mhc1"}, or \code{"Mhtc1"}.
##'
##' @return A matrix with two columns: first column for \eqn{z_ik} and second column for \eqn{z_ik0}.
##'
##' @export
##'
zik_fun <- function (x, K, k, histCap_individual, model) {
  switch(model,
         "Mh" = cbind(c( 1, x), c( 1, x)),
         "Mht" = cbind(c( x, ((1:K)==k)+0), c( x, ((1:K)==k)+0)),
         "Mhb" = cbind(c( 1, x, histCap_individual), c( 1, x, 0)),
         "Mhtb" = cbind(c( x, ((1:K)==k)+0, histCap_individual),c( x, ((1:K)==k)+0, 0)),
         "Mhc1" = cbind(c( 1, x, histCap_individual), c( 1, x, 0)),
         "Mhtc1" = cbind(c( x, ((1:K)==k)+0, histCap_individual),c( x, ((1:K)==k)+0, 0))
  )
}


##' \eqn{z_{ik}} and \eqn{z_{ik0}} for the discrete-time models "Mhbc1" and "Mhtbc1"
##'
##' @description Function to calculate \eqn{z_{ik}} and \eqn{z_{ik0}} used in the function \code{abun_dt_htbc1}.
##'
##' @param x A vector, the individual covariates without constant one.
##' @param K A number, the number of capture occasions.
##' @param k A number, the current capture occasion.
##' @param histCap_individual1 A vector with elements being 0 or 1. 1 and 0 respectively indicate whether an individual was captured before or not.
##' @param histCap_individual2 A vector with elements being 0 or 1. 1 and 0 respectively indicate whether an individual was captured on the most recent occasion \eqn{k-1} or not.
##' @param model A character, used to specify model \code{"Mhbc1"} or \code{"Mhtbc1"}.
##'
##' @return A matrix with two columns: first column for \eqn{z_ik} and second column for \eqn{z_ik0}.
##'
##' @export
##'
zik_fun_bc1 <- function (x, K, k, histCap_individual1, histCap_individual2, model) {
  switch( model,
          "Mhbc1" = cbind(c( 1, x, histCap_individual1, histCap_individual2), c( 1, x, 0, 0)),
          "Mhtbc1" = cbind(c( x, ((1:K)==k)+0, histCap_individual1, histCap_individual2),c( x, ((1:K)==k)+0, 0, 0)) )
}


##' Penalized log EL for general discrete-time models
##'
##' @description  Function to calculate the penalized empirical log-likelihood (log EL) function for general discrete-time capture probability models when capture history is known.
##'
##' @param N A number, the population size.
##' @param n A number, the sample size.
##' @param alpha A number, the probability of never being captured.
##' @param prob A vector, the probability masses of individual covariates.
##' @param d A matrix, the capture history.
##' @param zik A 3-dimensional array. First dimension represents the individuals, second dimension the capture occasions, third dimension the summarized vectors defined by the function \code{\link{zik_fun}} or \code{\link{zik_fun_bc1}} .
##' @param beta A vector or matrix with a single column, which represents the regression coefficients.
##' @param Cp A number, the penalty coefficient.
##' @param Nchao A number, the Chao (1987)'s lower bound.
##'
##' @return a number, the penalized empirical log-likelihood.
##'
##' @references
##' Chao, A. (1987).
##' Estimating the population size for capture--recapture data with unequal catchability.
##' \emph{Biometrics} \strong{43}, 783-791.
##'
##' @importFrom stats plogis
##'
##' @export
##'
loglikelihood_htbc1 <- function ( N, n, alpha, prob, d, zik, beta, Cp, Nchao ) {

  beta <- as.numeric(beta)
  g <- apply( zik, c(1,2), function(x) plogis(sum(x*beta)) )

  sum( log( N + 1 - c(1:n) ) ) - sum(log(1:n)) + (N - n) * log( alpha + 1e-300 ) +
    sum( d * log(g + 1e-300) + (1 - d) * log(1 - g + 1e-300) ) +
    sum( log( prob + 1e-300 ) ) -
    Cp * (N - Nchao)^2 * (N > Nchao)
}


##' Maximum penalized EL estimates for discrete-time models
##'
##' @description Function to calculate the maximum penalized empirical likelihood (EL) estimates for general discrete-time capture probability models using the EM algorithm.
##'
##' @inheritParams abun_dt
##' @param N0 A number, at which the population size \eqn{N} is fixed when calculating the profile log-likelihood in the \code{\link{abun_dt_ci}} function. It is \code{NULL} when calculating the maximum penalized EL estimates.
##'
##' @return A \code{abun_dt} object
##'
##' @importFrom methods new
##' @importFrom stats coef glm optimize plogis
##'
##' @export
##'
abun_dt_htbc1 <- function ( histCap, x, model = "Mh", method = "EL",
                          eps = 1e-5, maxN = NULL, N0 = NULL, Cp = 0 )  {

  ### initialization
  d <- as.matrix(histCap)
  n <- dim(d)[1]
  K <- dim(d)[2]
  if( is.null(maxN) ) maxN <- 100*n

  ### Chao (1987)'s lower bound of N
  d_tot <- apply(d, 1, sum)
  f1 <- sum(d_tot == 1)
  f2 <- sum(d_tot == 2)
  Nchao <- n + f1^2/(2*f2)
  Nchao <- min(Nchao, 1e20)

  if (method == "PEL" & Cp == 0)  Cp <- 2 * f2^2 / (n * f1^4)

  x_mat <- as.matrix(x)
  d_ext <- cbind(0, d)
  x_dim <- ncol(x_mat)
  beta <- matrix(0, nrow = switch( model,
                                   'Mh' = x_dim + 1,
                                   'Mht' = x_dim + K,
                                   'Mhb' = x_dim + 2,
                                   'Mhtb' = x_dim + K + 1,
                                   'Mhc1' = x_dim + 2,
                                   'Mhbc1' = x_dim + 3,
                                   'Mhtc1' = x_dim + K + 1,
                                   'Mhtbc1' = x_dim + K + 2))

  bt_dim <- length(beta)
  zik <- array(dim = c(n, K, bt_dim))
  zik0 <- array(dim = c(n, K, bt_dim))
  for (i in 1:n)
    for (k in 1:K) {
      if (model %in% c('Mh', 'Mht', 'Mhb', 'Mhtb')) {
        ziks <- zik_fun( x_mat[i,], K, k, (sum(d_ext[i, 1:k])>0)+0, model )
      } else {

        if (model %in% c('Mhc1', 'Mhtc1')) {
          ziks <- zik_fun( x_mat[i,], K, k, d_ext[i, k], model )
        } else {

          ## model %in% c('Mhbc1', 'Mhtbc1')
          ziks <- zik_fun_bc1( x_mat[i,], K, k, (sum(d_ext[i, 1:k])>0) + 0, d_ext[i, k], model )
        }
      }

      zik[i, k, ] <- ziks[,1]
      zik0[i, k, ] <- ziks[,2]
    }

  nx <- rbind( apply(zik, 3, rbind), apply(zik0, 3, rbind) )
  ny <- c( c(d), rep(0, n*K) )

  g0 <- apply( zik0, c(1,2), function(x) plogis(sum(x*beta)) )
  phi <- as.numeric( apply( (1-g0), 1, prod ) )
  prob <- rep(1/n, n)
  alpha <- sum(phi * prob)

  N <- ifelse ( is.null(N0), n/( 1 - alpha + 1e-300 ), N0 )

  pars <- c(N, beta,  alpha)
  likes <- loglikelihood_htbc1(N, n, alpha, prob, d, zik, beta, Cp, Nchao)

  ### iteration

  err <- 1; nit <- 0

  while (err > eps) {

    nit <- nit + 1

    ### update beta
    wi <- ( N - n ) * phi * prob/( alpha + 1e-300 )
    nwi <- c( rep(1, n*K), rep(wi, K) )
    out <- glm(ny ~ nx - 1, family="binomial", weights = nwi)
    beta <- as.matrix( coef(out) )
    g0 <- apply(zik0, c(1,2), function(x) plogis(sum(x*beta)))
    phi <- as.numeric( apply( (1-g0), 1, prod ) )

    ### update porb & alpha
    prob <- (wi + 1) / N
    alpha <- sum( phi * prob )

    ### update N
    if ( is.null(N0) ){

      obj_N <- function (nt) {
        sum( log( nt + 1 - c(1:n) ) ) + (nt - n)*log(alpha + 1e-300) -
          Cp * (nt - Nchao)^2 * (nt > Nchao)
      }

      N <- optimize(obj_N, lower=n, upper=maxN, maximum=TRUE, tol = 0.001)$maximum
    }


    ### calculate the log-likelihood
    pars <- rbind( pars, c(N, beta, alpha) )
    likes <- c(likes, loglikelihood_htbc1(N, n, alpha, prob, d, zik, beta, Cp, Nchao))

    ### stopping criterion
    err <- abs( likes[nit+1] - likes[nit] )

  }

  AIC <- 2*( - likes[nit+1] + 2 + length(beta))
  t1 <- apply(d, 1, function(x) min(which(x == 1)))

  rt <- new('abun_dt',
            model = model, method = method,
            N = N, Nchao = Nchao,
            beta = as.numeric(beta), alpha = alpha,
            loglikelihood = likes[nit+1], AIC = AIC,
            prob = prob, nit = nit, pars = pars, loglikelihoods = likes,
            histCap = d, numCap = apply(d, 1, sum), K = K,
            t1 = t1, x = x_mat,
            eps = eps, maxN = maxN, Cp = Cp)
  return(rt)

}


