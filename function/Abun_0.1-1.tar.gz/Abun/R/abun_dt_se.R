##' Standard errors for the discrete-time models
##'
##' @description Function to calculate the standard errors, based on the asymptotic normality, of the maximum penalized empirical likelihood estimates for the discrete-time capture--recapture models.
##'
##' @param object A \code{abun_dt} object.
##'
##' @return A list with two elements:
##'
##' \itemize{
##'   \item se_N, the standard error for the population size.
##'   \item se_beta, the standard error for the regression coefficients in the capture probability models.
##' }
##'
##'
##' @export
##'
abun_dt_se <- function (object) {

  switch( object@model,
          "Mh" = abun_dt_h_se(object),
          "Mhb" = abun_dt_hb_se(object),
          "Mht" = abun_dt_htbc1_se(object),
          "Mhtb" = abun_dt_htbc1_se(object),
          "Mhc1" = abun_dt_htbc1_se(object),
          "Mhtc1" = abun_dt_htbc1_se(object),
          "Mhbc1" = abun_dt_htbc1_se(object),
          "Mhtbc1" = abun_dt_htbc1_se(object) )

}


abun_dt_h_se <- function (object) {

  x_mat <- as.matrix( object@x )
  z_mat <- cbind( 1, x_mat )
  numCap <- object@numCap
  n <- length(numCap)
  K <- object@K
  N <- object@N
  beta <- as.matrix(object@beta)

  g <- as.numeric( plogis( z_mat%*%beta ) )
  phi <- (1 - g)^K
  varphi <- sum( 1/(1-phi+1e-300)^2 )/N


  ### Vij's
  V22.coef <- ( numCap - K*g/(1-phi+1e-300) )^2
  V22 <- - ( t(z_mat) %*% diag(V22.coef, n, n) %*% z_mat )/N
  V23 <- ( t(z_mat) %*% ( phi*K*g/(1-phi+1e-300)^2 ) )/N
  V23 <- as.matrix(V23)

  V22_chol <- forwardsolve( t(chol(- V22)), diag(1, nrow(V22)))
  V2223_chol <- forwardsolve( t( chol( - V22) ), V23 )
  rt <- list( se_N = as.numeric( sqrt((varphi - 1 + t(V2223_chol)%*%V2223_chol)*N) ),
              se_beta = sqrt( diag( t(V22_chol)%*%V22_chol/N ) ) )

  return(rt)

}


abun_dt_hb_se <- function (object) {

  x_mat <- as.matrix( object@x )
  z_mat <- cbind( 1, x_mat )
  z_mat0 <- cbind(z_mat, 0)
  z_mat1 <- cbind(z_mat, 1)

  numCap <- object@numCap
  t1 <- object@t1
  n <- length(numCap)
  K <- object@K
  N <- object@N
  beta <- as.matrix(object@beta)

  g0 <- plogis( as.numeric(z_mat0%*%beta) )
  g1 <- plogis( as.numeric(z_mat1%*%beta) )
  phi <- (1 - g0)^K
  varphi <- sum( 1/(1-phi+1e-300)^2 )/N

  bt_dim <- length(beta)
  V23 <- matrix(0, bt_dim)
  V22 <- matrix(0, bt_dim, bt_dim)

  for (i in 1:n) {

    # temp1 <- (1 - t1[i]*g0[i]) * z_mat0[i, ] +
    #   (numCap[i] - 1)*(1 - g1[i]) * z_mat1[i, ] -
    #   (K - t1[i] - numCap[i] + 1) * g1[i] * z_mat1[i, ]
    temp1 <- (1 - t1[i])*g0[i] * z_mat0[i, ] +
      (1 - g0[i]) * z_mat0[i, ] +
      (numCap[i] - 1)*(1 - g1[i]) * z_mat1[i, ] -
      (K - t1[i] - numCap[i] + 1) * g1[i] * z_mat1[i, ]
    temp2 <- K * g0[i] * z_mat0[i,]

    V22.frt <- temp1 - phi[i] * temp2 /(1-phi[i]+1e-300)
    V22.frt <- as.matrix(V22.frt)
    V22 <- V22 - V22.frt%*%t(V22.frt)

    V23 <- V23 + phi[i]* temp2/(1 - phi[i]+1e-300)^2

  }

  V22 <- V22/N
  V23 <- V23/N

  V22_chol <- forwardsolve( t(chol(- V22)), diag(1, nrow(V22)))
  V2223_chol <- forwardsolve( t( chol( - V22) ), V23 )
  rt <- list( se_N = as.numeric( sqrt((varphi - 1 + t(V2223_chol)%*%V2223_chol)*N) ),
              se_beta = sqrt( diag( t(V22_chol)%*%V22_chol/N ) ) )

  return(rt)

}


abun_dt_htbc1_se <- function (object) {

  x_mat <- as.matrix( object@x )
  d <- as.matrix( object@histCap )
  d_ext <- cbind(0, d)
  n <- dim(d)[1]
  K <- dim(d)[2]
  N <- object@N
  beta <- as.matrix(object@beta)
  model <- object@model

  g <- matrix(NA, n, K)
  g0 <- matrix(NA, n, K)

  for (i in 1:n)
    for (k in 1:K) {
      if (model %in% c('Mh', 'Mht', 'Mhb', 'Mhtb')) {
        ziks <- zik_fun( x_mat[i,], K, k, (sum(d_ext[i, 1:k])>0)+0, model )
      } else {

        if (model %in% c('Mhc1', 'Mhtc1')) {
          ziks <- zik_fun( x_mat[i,], K, k, d_ext[i, k], model )
        } else {

          ## model %in% c('Mhbc1', 'Mhtbc1')
          ziks <- zik_fun_bc1( x_mat[i,], K, k, (sum(d_ext[i, 1:k])>0) + 0, d_ext[i, k], model )
        }
      }

      g[i, k] <- plogis( t(ziks[,1])%*%beta )
      g0[i, k] <- plogis( t(ziks[,2])%*%beta )
    }

  phi <- as.numeric( apply( (1-g0), 1, prod ) )
  varphi <- sum( 1/(1 - phi + 1e-300)^2 )/N

  bt_dim <- length(beta)
  V23 <- matrix(0, bt_dim)
  V22 <- matrix(0, bt_dim, bt_dim)

  for (i in 1:n) {

    temp1 <- 0
    temp2 <- 0

    for ( k in 1:K ) {

      if ( model %in% c('Mh', 'Mht', 'Mhb', 'Mhtb') ) {
        ziks <- zik_fun( x_mat[i,], K, k, (sum(d_ext[i, 1:k])>0)+0, model )
      } else {

        if ( model %in% c('Mhc1', 'Mhtc1') ) {
          ziks <- zik_fun( x_mat[i,], K, k, d_ext[i, k], model )
        } else {

          ## model %in% c('Mhbc1', 'Mhtbc1')
          ziks <- zik_fun_bc1( x_mat[i,], K, k, (sum(d_ext[i, 1:k])>0) + 0, d_ext[i, k], model )
        }
      }

      zik <- as.matrix(ziks[,1])
      zik0 <- as.matrix(ziks[,2])
      temp1 <- temp1 + (d[i,k] - g[i,k])*zik
      temp2 <- temp2 + g0[i,k] * zik0

    }

    V22.frt <- temp1 - phi[i] * temp2/(1-phi[i]+1e-300)
    V22 <- V22 - V22.frt%*%t(V22.frt)

    V23 <- V23 + phi[i]* temp2/(1 - phi[i]+1e-300)^2

  }

  V22 <- V22/N
  V23 <- V23/N

  V22_chol <- forwardsolve( t(chol(- V22)), diag(1, nrow(V22)) )
  V2223_chol <- forwardsolve( t( chol( - V22) ), V23 )
  rt <- list( se_N = as.numeric( sqrt((varphi - 1 + t(V2223_chol)%*%V2223_chol)*N) ),
              se_beta = sqrt( diag( t(V22_chol)%*%V22_chol/N ) ) )

  return(rt)

}

