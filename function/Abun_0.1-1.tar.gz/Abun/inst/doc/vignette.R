### R code from vignette source 'vignette.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: vignette.Rnw:110-112
###################################################
library(Abun)
data(blackbear)


###################################################
### code chunk number 2: vignette.Rnw:131-132
###################################################
head(blackbear)


###################################################
### code chunk number 3: vignette.Rnw:175-178
###################################################
numCap <- apply(blackbear[,1:8], 1, sum)
x <- data.frame(sex = blackbear$sex)
(bear_h_el <- abun_dt(numCap = numCap, K = 8, x = x))


###################################################
### code chunk number 4: vignette.Rnw:194-198
###################################################
t1 <- apply(blackbear[,1:8], 1, function(x) min(which(x == 1)))
bear_hb_el <- abun_dt(numCap = numCap, K = 8, t1 = t1,
                      x = x, model = "Mhb")
bear_hb_el@N


###################################################
### code chunk number 5: vignette.Rnw:213-218
###################################################
bear_htb_el <- abun_dt(histCap = blackbear[,1:8],
                       x = x, model = "Mhtb")
bear_htb_pel <- abun_dt(histCap = blackbear[,1:8], x = x,
                        model = "Mhtb", method = "PEL")
c(bear_htb_el@N, bear_htb_pel@N)


###################################################
### code chunk number 6: vignette.Rnw:240-242
###################################################
abun_dt_ci(bear_htb_el, UB = 1E5)
abun_dt_ci(bear_htb_pel, level = 0.95)


###################################################
### code chunk number 7: vignette.Rnw:252-271
###################################################
loglike <- bear_htb_el@loglikelihood
ploglike <- bear_htb_pel@loglikelihood
Ns <- seq(48, 400, length.out = 20)
elr <- rep(0, 20)
pelr <- rep(0, 20)
for ( i in 1:20) {
  loglike_null <- abun_dt_htbc1(
    histCap = blackbear[,1:8], x = blackbear$sex,
    model = "Mhtb", N0 = Ns[i])
  ploglike_null <- abun_dt_htbc1(
    histCap = blackbear[,1:8], x = blackbear$sex,
    model = "Mhtb", N0 = Ns[i], method = "PEL")
  elr[i] <- 2*(loglike - loglike_null@loglikelihood)
  pelr[i] <- 2*(ploglike - ploglike_null@loglikelihood)
}
plot(Ns, elr, xlab = "N", ylab = "Likelihood ratio function",
     type = "l", lty = 2)
lines(Ns, pelr)
legend("top", c("PEL", "EL"), lty = c(1, 2), bty="n")


###################################################
### code chunk number 8: vignette.Rnw:290-291
###################################################
summary(bear_hb_el)


###################################################
### code chunk number 9: vignette.Rnw:305-308
###################################################
boot <- abun_dt_boot(bear_hb_el, B = 200) # B is the number of bootstrap samples
boot$se_N
boot$quant[c("2.5%", "97.5%")]


###################################################
### code chunk number 10: vignette.Rnw:327-328
###################################################
data("prinia")


###################################################
### code chunk number 11: vignette.Rnw:387-396
###################################################
numCap <- prinia$y
x <- data.frame(wing = prinia$x, wing2 = prinia$x^2)
prinia_h_el <- abun_ct( numCap = numCap, x = x,
                        tau = 17, model = "Mh" )
summary(prinia_h_el)@abundance

prinia_h_pel <- abun_ct( numCap = numCap, x = x,
                         tau = 17, method = "PEL" )
summary(prinia_h_pel)@abundance


###################################################
### code chunk number 12: vignette.Rnw:404-407
###################################################
prinia_hb_pel <- abun_ct( numCap = numCap, x = x, t1 = prinia$t1,
                          tau = 17, model = "Mhb" , method = "PEL")
summary(prinia_hb_pel)


###################################################
### code chunk number 13: vignette.Rnw:449-451
###################################################
abun_ct_ci(prinia_h_el)
abun_ct_ci(prinia_h_pel)


